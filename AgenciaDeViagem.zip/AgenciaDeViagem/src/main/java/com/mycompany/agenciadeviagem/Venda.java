
package com.mycompany.agenciadeviagem;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Venda {
    private final String nomeCliente;
    private final String formaPagamento;
    private final LocalDate data;
    private final PacoteViagem pacote;
    private final double margemLucro;
    private final double taxasAdicionais;

    public Venda(String nomeCliente, String formaPagamento, String data, 
                PacoteViagem pacote, double margemLucro, double taxasAdicionais) {
        this.nomeCliente = nomeCliente;
        this.formaPagamento = formaPagamento;
        this.data = LocalDate.parse(data, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        this.pacote = pacote;
        this.margemLucro = margemLucro;
        this.taxasAdicionais = taxasAdicionais;
    }

    public double converterParaReais(double cotacaoDolar) {
        double totalDolar = pacote.calcularTotalPacote(margemLucro, taxasAdicionais);
        return totalDolar * cotacaoDolar;
    }

    public void mostrarDetalhesVenda(double cotacaoDolar) {
        double totalDolar = pacote.calcularTotalPacote(margemLucro, taxasAdicionais);
        double totalReais = converterParaReais(cotacaoDolar);
        
        System.out.println("\n--- Detalhes da Venda ---");
        System.out.println("Cliente: " + nomeCliente);
        System.out.println("Forma de Pagamento: " + formaPagamento);
        System.out.println("Data: " + data.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        System.out.println("Destino: " + pacote.getDestino());
        System.out.printf("Total do Pacote em Dólar: $%.2f%n", totalDolar);
        System.out.printf("Total do Pacote em Reais: R$%.2f%n", totalReais);
    }
}
