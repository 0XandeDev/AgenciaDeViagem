package com.mycompany.agenciadeviagem;

public class Transporte {
    // Atributos da classe (declarados no nível da classe, não dentro de métodos)
    private final String tipo;
    private final double valor;

    // Construtor
    public Transporte(String tipo, double valor) {
        this.tipo = tipo;
        this.valor = valor;
    }

    // Métodos getters
    public String getTipo() {
        return tipo;
    }

    public double getValor() {
        return valor;
    }

    // Método toString
    @Override
    public String toString() {
        return String.format("Transporte [tipo=%s, valor=%.2f]", tipo, valor);
    }
}