
package com.mycompany.agenciadeviagem;


public class Hospedagem {
    private final String tipo;
    private final double valorDiaria;

    public Hospedagem(String tipo, double valorDiaria) {
        this.tipo = tipo;
        this.valorDiaria = valorDiaria;
    }

    public String getTipo() {
        return tipo;
    }

    public double getValorDiaria() {
        return valorDiaria;
    }

    @Override
    public String toString() {
        return String.format("Hospedagem [tipo=%s, valorDiaria=%.2f]", tipo, valorDiaria);
    }
}
