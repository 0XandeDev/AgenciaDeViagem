
package com.mycompany.agenciadeviagem;


import java.util.Scanner;

public class AgenciaDeViagem {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("=== SISTEMA DE AGÊNCIA DE VIAGENS ===");
            
            // Cadastro do Pacote de Viagem
            System.out.println("\n--- Cadastro de Pacote de Viagem ---");
            
            System.out.print("Tipo de Transporte (aéreo, rodoviário, marítimo etc.): ");
            String tipoTransporte = scanner.nextLine();
            
            System.out.print("Valor do Transporte (em dólar): ");
            double valorTransporte = scanner.nextDouble();
            scanner.nextLine(); // Limpar buffer
            
            System.out.print("Tipo de Hospedagem: ");
            String tipoHospedagem = scanner.nextLine();
            
            System.out.print("Valor da Diária (em dólar): ");
            double valorDiaria = scanner.nextDouble();
            scanner.nextLine(); // Limpar buffer
            
            System.out.print("Destino: ");
            String destino = scanner.nextLine();
            
            System.out.print("Quantidade de Dias: ");
            int quantidadeDias = scanner.nextInt();
            scanner.nextLine(); // Limpar buffer
            
            // Criar objetos de transporte e hospedagem
            Transporte transporte = new Transporte(tipoTransporte, valorTransporte);
            Hospedagem hospedagem = new Hospedagem(tipoHospedagem, valorDiaria);
            
            // Criar pacote de viagem
            PacoteViagem pacote = new PacoteViagem(transporte, hospedagem, destino, quantidadeDias);
            
            System.out.println("\n--- Informações do Pacote ---");
            System.out.println(pacote);
            
            System.out.print("\nMargem de Lucro (%): ");
            double margemLucro = scanner.nextDouble();
            
            System.out.print("Taxas Adicionais (em dólar): ");
            double taxasAdicionais = scanner.nextDouble();
            scanner.nextLine(); // Limpar buffer
            
            double totalPacote = pacote.calcularTotalPacote(margemLucro, taxasAdicionais);
            System.out.printf("\nTotal do Pacote: $%.2f%n", totalPacote);
            
            // Cadastro da Venda
            System.out.println("\n--- Cadastro de Venda ---");
            
            System.out.print("Nome do Cliente: ");
            String nomeCliente = scanner.nextLine();
            
            System.out.print("Forma de Pagamento: ");
            String formaPagamento = scanner.nextLine();
            
            System.out.print("Data da Venda (dd/MM/yyyy): ");
            String dataVenda = scanner.nextLine();
            
            // Criar venda
            Venda venda = new Venda(nomeCliente, formaPagamento, dataVenda, pacote, margemLucro, taxasAdicionais);
            
            System.out.print("Cotação do Dólar (em reais): ");
            double cotacaoDolar = scanner.nextDouble();
            
            // Mostrar detalhes da venda
            venda.mostrarDetalhesVenda(cotacaoDolar);
        }
    }
}