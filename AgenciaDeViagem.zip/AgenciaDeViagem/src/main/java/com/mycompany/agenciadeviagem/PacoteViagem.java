package com.mycompany.agenciadeviagem;


public class PacoteViagem {
    private final Transporte transporte;
    private final Hospedagem hospedagem;
    private final String destino;
    private final int quantidadeDias;

    public PacoteViagem(Transporte transporte, Hospedagem hospedagem, String destino, int quantidadeDias) {
        this.transporte = transporte;
        this.hospedagem = hospedagem;
        this.destino = destino;
        this.quantidadeDias = quantidadeDias;
    }

    public double calcularTotalHospedagem() {
        return quantidadeDias * hospedagem.getValorDiaria();
    }

    public double calcularValorLucro(double margem) {
        double valorBase = transporte.getValor() + calcularTotalHospedagem();
        return valorBase * (1 + margem / 100);
    }

    public double calcularTotalPacote(double margemLucro, double taxasAdicionais) {
        return calcularValorLucro(margemLucro) + taxasAdicionais;
    }

    public String getDestino() {
        return destino;
    }

    @Override
    public String toString() {
        return String.format(
            "PacoteViagem [destino=%s, dias=%d, transporte=%s, hospedagem=%s]",
            destino, quantidadeDias, transporte, hospedagem
        );
    }
}